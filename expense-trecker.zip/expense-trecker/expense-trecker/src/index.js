"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// index.ts
const readline = require("readline");
const expense_1 = require("./expense");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
let expenses = [];
let idCounter = 1;
function showMenu() {
    console.log("\n--- Expense Tracker ---");
    console.log("1. Add expense");
    console.log("2. Show all expenses");
    console.log("3. calculate sum of all expenses");
    console.log("4. filter expenses by category");
    console.log("5. exit");
    rl.question("choose option: ", handleMenu);
}
function handleMenu(choice) {
    switch (choice) {
        case "1":
            addExpense();
            break;
        case "2":
            viewExpenses();
            break;
        case "3":
            calculateTotal();
            break;
        case "4":
            filterExpenses();
            break;
        case "5":
            rl.close();
            break;
        default:
            console.log("Wrong choose,try again");
            showMenu();
    }
}
function addExpense() {
    rl.question("Expanse name: ", (name) => {
        rl.question("Expanse price: ", (amount) => {
            rl.question("Category (Food, Transport, Entertainment, Other): ", (categoryInput) => {
                if (!(categoryInput in expense_1.Category)) {
                    console.log("Wrong category.");
                    return showMenu();
                }
                const expense = {
                    id: idCounter++,
                    name,
                    amount: parseFloat(amount),
                    category: categoryInput,
                    date: new Date()
                };
                expenses.push(expense);
                console.log("Expence added!");
                showMenu();
            });
        });
    });
}
function viewExpenses() {
    if (expenses.length === 0) {
        console.log("No expense.");
    }
    else {
        console.log("\n--- All expensies ---");
        expenses.forEach(expense => {
            console.log(`#${expense.id} | ${expense.name} | ${expense.amount} grn | ${expense.category} | ${expense.date.toLocaleDateString()}`);
        });
    }
    showMenu();
}
function calculateTotal() {
    const total = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    console.log(`Total price of expanses: ${total} grn`);
    showMenu();
}
function filterExpenses() {
    rl.question("insert category to filter (Food, Transport, Entertainment, Other): ", (categoryInput) => {
        if (!(categoryInput in expense_1.Category)) {
            console.log("wrong category.");
            return showMenu();
        }
        const filtered = expenses.filter(expense => expense.category === categoryInput);
        if (filtered.length === 0) {
            console.log("any expensies at this category.");
        }
        else {
            console.log("\n--- expensies at this category " + categoryInput + " ---");
            filtered.forEach(expense => {
                console.log(`#${expense.id} | ${expense.name} | ${expense.amount} grn | ${expense.date.toLocaleDateString()}`);
            });
        }
        showMenu();
    });
}
showMenu();
//# sourceMappingURL=index.js.map