"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Category = void 0;
// expense.ts
var Category;
(function (Category) {
    Category["Food"] = "Food";
    Category["Transport"] = "Transport";
    Category["Entertainment"] = "Entertainment";
    Category["Other"] = "Other";
})(Category = exports.Category || (exports.Category = {}));
//# sourceMappingURL=expense.js.map